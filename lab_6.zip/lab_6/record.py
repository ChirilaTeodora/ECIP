import sounddevice as sd
import soundfile as sf

def record_and_play(duration, fs, filename):
    data = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()
    
    sf.write(filename, data, fs)
    
    sd.play(data, fs)
    sd.wait()

if __name__ == "__main__":
    fs = 44100
    duration = 6
    filename = "conversation.wav"
    
    record_and_play(duration, fs, filename)