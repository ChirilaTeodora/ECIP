import speech_recognition as sr
import jiwer
import matplotlib.pyplot as plt

def transcribe_audio(file_path):
    recognizer = sr.Recognizer()
    try:
        with sr.AudioFile(file_path) as source:
            audio_data = recognizer.record(source)
        return recognizer.recognize_google(audio_data)
    except sr.UnknownValueError:
        return "[UNRECOGNIZABLE]"
    except sr.RequestError:
        return "[API CONNECTION ERROR]"
    except FileNotFoundError:
        return "[FILE NOT FOUND]"

def calculate_error(reference, hypothesis):
    return jiwer.wer(reference, hypothesis)

if __name__ == "__main__":
    reference_text = "ba da el de ce vrea dialog mai exact, nu stiu , nici eu "
    
    files_to_test = {
        "Raw Audio": "received_original.wav",
        "Processed Audio": "processed_clarified.wav"
    }
    
    labels = []
    error_rates = []
    
    for label, file_name in files_to_test.items():
        print(f"\n--- Testing: {label} ---")
        print(f"File: {file_name}")
        
        transcription = transcribe_audio(file_name)
        print(f"AI Heard: {transcription}")
        
        if transcription not in ["[UNRECOGNIZABLE]", "[API CONNECTION ERROR]", "[FILE NOT FOUND]"]:
            error = calculate_error(reference_text, transcription)
        else:
            error = 1.0
            
        print(f"Word Error Rate (WER): {error:.2f}")
        
        labels.append(label)
        error_rates.append(error)
        
    plt.figure(figsize=(8, 6))
    colors = ['red', 'green']
    plt.bar(labels, error_rates, color=colors, width=0.5)
    plt.title('Speech-to-Text Error Rate: Raw vs Processed (2 Meters)')
    plt.ylabel('Word Error Rate (WER)')
    plt.ylim(0, max(1.2, max(error_rates) + 0.2))
    
    for i, v in enumerate(error_rates):
        plt.text(i, v + 0.02, str(round(v, 2)), ha='center', fontweight='bold')
        
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.savefig("comparison_chart.png")
    plt.show()