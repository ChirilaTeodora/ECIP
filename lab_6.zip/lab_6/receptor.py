import sounddevice as sd
import soundfile as sf

def play_audio(file_path):
    data, fs = sf.read(file_path)
    sd.play(data, fs)
    sd.wait()

if __name__ == "__main__":
    play_audio("conversation.wav")