import sounddevice as sd
import numpy as np
from scipy.signal import butter, lfilter
import soundfile as sf

def record_audio(duration, fs):
    recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()
    return recording.flatten(), fs

def amplify_signal(data, gain):
    return data * gain

def bandpass_filter(data, lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    y = lfilter(b, a, data)
    return y

if __name__ == "__main__":
    fs = 44100
    duration = 6
    
    recorded_data, fs = record_audio(duration, fs)
    
    amplified_data = amplify_signal(recorded_data, 2.5)
    
    filtered_data = bandpass_filter(amplified_data, 300.0, 3400.0, fs, order=6)
    
    sf.write("received_original.wav", recorded_data, fs)
    sf.write("processed_clarified.wav", filtered_data, fs)